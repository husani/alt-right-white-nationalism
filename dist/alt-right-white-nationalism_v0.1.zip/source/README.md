The rise of the so-called 'alt-right' is, essentially, white nationalism. For purposes of accuracy, this Chrome extension replaces all mentions of 'alt-right' with more accurate terms.

[Submit a pull request if you have more ideas](https://github.com/husani/alt-right-white-nationalism)